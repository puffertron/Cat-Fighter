# Platypus
Defold platformer engine.

# Setup
You can use the extension in your own project by adding this project as a [Defold library dependency](http://www.defold.com/manuals/libraries/). Open your game.project file and in the dependencies field under project add:

https://github.com/britzl/Platypus/archive/master.zip

Or point to the ZIP file of a [specific release](https://github.com/britzl/Platypus/releases).

# Example
See an example of Platypus in action by running the `grottoescape.collection` of this project or try [the HTML5 demo](https://britzl.github.io/Platypus/).


# Usage

## Creating an instance
Use `platypus.create()` to create a Platypus instance. Use this to control a single game object. Each frame you need to call `platypus.update()` and `platypus.on_message()`.

	function init(self)
		self.platypus = platypus.create(config)
	end

	function update(dt)
		self.platypus.update(dt)
	end

	function on_message(self, message_id, message, sender)
		self.platypus.on_message(message_id, message)
	end


## Player movement
Use `platypus.left()`, `platypus.right()`, `platypus.up()`, `platypus.down()` and  `platypus.move()` to move the player. The movement will happen during the next call to `platypus.update()`.

	function init(self)
		self.platypus = platypus.create(config)
	end

	function update(dt)
		self.platypus.update(dt)
	end

	function on_message(self, message_id, message, sender)
		self.platypus.on_message(message_id, message)
	end

	function on_input(self, action_id, action)
		if action_id == hash("left") then
			self.platypus.left(250)
		elseif action_id == hash("right") then
			self.platypus.right(250)
		end
	end

## Jumping
Platypus supports normal jumps when standing on the ground, wall jumps when in contact with a wall in the air and double jumps. Use `platypus.jump()` to perform a jump and `platypus.abort_jump()` to reduce the height of a jump that is already in progress.

	function init(self)
		self.platypus = platypus.create(config)
	end

	function update(dt)
		self.platypus.update(dt)
	end

	function on_message(self, message_id, message, sender)
		self.platypus.on_message(message_id, message)
	end

	function on_input(self, action_id, action)
		if action_id == hash("jump") then
			if action.pressed then
				self.platypus.jump(800)
			elseif action.released then
				self.platypus.abort_jump(0.5)
			end
		end
	end

## Collision detection
Platypus uses a combination of contact point response handling and ray casts. Contact point response handling is used to separate the game object from the colliding geometry and ray casts are used to detect wall and ground contact.

## State changes
Platypus will send messages for certain state changes so that scripts can react, for instance by changing animation.

	function init(self)
		self.platypus = platypus.create(config)
	end

	function update(dt)
		self.platypus.update(dt)
	end

	function on_message(self, message_id, message, sender)
		self.platypus.on_message(message_id, message)
		if message_id == platypus.FALLING then
			print("I'm falling")
		elseif message_id == platypus.GROUND_CONTACT then
			print("Phew! Solid ground")
		elseif message_id == platypus.WALL_CONTACT then
			print("Ouch!")
		end
	end


# Platypus API

## Functions

### platypus.create(config)
Create an instance of Platypus. This will provide all the functionality to control a game object in a platformer game. The functions will operate on the game object attached to the script calling the functions.

**PARAMETERS**
* `config` (table) - Table with configuration values

The ```config``` table can have the following values:

* `collisions` (table) - Lists of collision groups (REQUIRED)
* `gravity` (number) - Gravity (pixels/s) (OPTIONAL)
* `max_velocity` (number) - Maximum velocity of the game object (pixels/s). Set this to limit speed and prevent full penetration of game object into level geometry (OPTIONAL)
* `wall_jump_power_ratio_x` (number) - Amount to multiply the jump power with when applying horizontal velocity during a wall jump (OPTIONAL)
* `wall_jump_power_ratio_y` (number) - Amount to multiply the jump power with when applying vertical velocity during a wall jump (OPTIONAL)

The `collisions` table can have the following values:

* `ground` (table) - List with collision group hashes for collision objects representing ground
* `left` (number) - Distance from game object center to left edge of collision shape
* `right` (number) - Distance from game object center to right edge of collision shape
* `top` (number) - Distance from game object center to top edge of collision shape
* `bottom` (number) - Distance from game object center to bottom edge of collision shape

**RETURN**
* `instance` (table) - The created Platypus instance

The `instance` table has all of the instance functions describe below in addition to the following fields:

* `wall_jump_power_ratio_x` - Value copied from `config` or assigned a default value
* `wall_jump_power_ratio_y` - Value copied from `config` or assigned a default value
* `gravity` - Value copied from `config` or assigned a default value
* `velocity` - The current velocity of the game object


### instance.update(dt)
Update the Platypus instance. This will move the game object and send out state changes.

**PARAMETERS**
* `dt` (number) - Delta time


### instance.on_message(message_id, message)
Forward received messages from the on_message lifecycle function to this instance function. This will handle collision messages and custom messages generated by the Platypus instance itself

**PARAMETERS**
* `message_id` (hash) - Id of the received message
* `message` (table) - The message data


### instance.left(velocity)
Move the game object to the left during next update. This will override any previous call to `instance.left()` or `instance.right()` as well as the horizontal velocity of `instance.move()`.

**PARAMETERS**
* `velocity` (number) - Amount to move left (pixels/s)


### instance.right(velocity)
Move the game object to the right during next update. This will override any previous call to `instance.left()` or `instance.right()` as well as the horizontal velocity of `instance.move()`.

**PARAMETERS**
* `velocity` (number) - Amount to move right (pixels/s)


### instance.up(velocity)
Move the game object up during next update. This will override any previous call to `instance.up()` or `instance.down()` as well as the vertical velocity of `instance.move()`.

**PARAMETERS**
* `velocity` (number) - Amount to move up (pixels/s)


### instance.down(velocity)
Move the game object down during next update. This will override any previous call to `instance.up()` or `instance.down()` as well as the vertical velocity of `instance.move()`.

**PARAMETERS**
* `velocity` (number) - Amount to move down (pixels/s)


### instance.move(velocity)
Move the game object during next update. This will override any previous call to `instance.left()`, `instance.right()`, `instance.up()`, `instance.down()` and `instance.move()`.

**PARAMETERS**
* `velocity` (vector3) - Amount to move (pixels/s)


### instance.jump(power, allow_double_jump, allow_wall_jump)
Make the game object perform a jump. This can either be a normal jump from standing on the ground, a wall jump if having wall contact and no ground contact, or a double jump if jumping up and not falling down.

**PARAMETERS**
* `power` (number) - Initial takeoff speed (pixels/s)
* `allow_double_jump` (boolean) - True if double jump is allowed
* `allow_wall_jump` (boolean) - True if wall jump is allowed


### instance.abort_jump(reduction)
Abort a jump by "cutting it short". This will reduce the vertical speed by some fraction.

**PARAMETERS**
* `reduction` (number) - Amount to multiply vertical velocity with


### instance.has_ground_contact()
Check if the game object is tanding on the ground

**RETURN**
* `ground_contact` (boolean) - True if standing on the ground


### instance.has_wall_contact()
Check if the game object is in contact with a wall

**RETURN**
* `wall_contact` (boolean) - True if in contact with a wall


### instance.is_falling()
Check if the game object is falling. The game object is considered falling if not having ground contact and velocity is pointing down.

**RETURN**
* `falling` (boolean) - True if falling


### instance.is_jumping()
Check if the game object is jumping. The game object is considered falling if not having ground contact and velocity is pointing up.

**RETURN**
* `jumping` (boolean) - True if jumping


## Messages

### platypus.FALLING
Sent once when the game object starts to fall

### platypus.GROUND_CONTACT
Sent once when the game object detects ground contact

### platypus.WALL_CONTACT
Sent once when the game object detects wall contact


# Credits
* Grotto Escape tiles - Ansimuz (https://ansimuz.itch.io/grotto-escape-game-art-pack)
